package com.fannie.collections;

import java.util.TreeSet;

public class SetEx3 {
	public static void main(String[] args) {
		TreeSet<String> set = new TreeSet<String>();
		
		set.add("Pratik");
		set.add("Sunil");
		set.add("Medha");
		set.add("Gergory");
		
		System.out.println(set);
	}
}
