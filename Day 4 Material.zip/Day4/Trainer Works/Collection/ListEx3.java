package com.fannie.collections;

import java.util.LinkedList;
import java.util.Vector;

public class ListEx3 {
	public static void main(String[] args) {
		Vector<String> list = new Vector<String>(5, 3);
		
		System.out.println("Size " + list.size());
		System.out.println("Capacity " + list.capacity());
		
		
		list.add("surya");
		list.add("Masud");
		list.add("Sandhya");
		list.add("Hemalatha");
		list.add("Hemalatha10");
		list.add("Hemalatha10");

		System.out.println("After -  Size " + list.size());
		System.out.println("After -  Capacity " + list.capacity());
		
		LinkedList<String> list1  = new LinkedList<String>();

		// you will try 
// linked list methods 
		// stack methods 
		
		// Queue methods 
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
