package com.fannie.step;

import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoanSanctionStep {
	@Given("^credit score is less than (\\d+)$")
	public void credit_score_is_less_than(int creditScore){
		System.out.println("Credit score is less than "+creditScore+".");
	}

	@Given("credit score is more than (\\d+)")
	public void credit_score_is_more_than_(int creditScore){
		System.out.println("Credit score is greater than "+creditScore+".");
	}

	@When("customer applies for the loan")
	public void customer_applies_for_loan(){
		System.out.println("Customer applies for the loan");
	}

	//	@Given("^.+$")
	//	public void random_method(String args){
	//		System.out.println("Hi, i am calling from the random method "+args);
	//	}

	//	@But("customer has to repay within 20 years")
	//	public void customer_has_to_repay_within_20_years(){
	//		System.out.println("Repay loan in 20 years");
	//	}

	@But("^customer has to repay within (\\d+) years$")
	public void customer_has_to_repay_within_years(int noOfYears){
		System.out.println("Repay loan in "+noOfYears+" years.");
	}

	@Then("sanction the loan")
	public void sanction_the_loan(){
		System.out.println("Loan is sanctioned.");
	}

	//	@Given("the customer works full time")
	//	public void the_customer_works_full_time() {
	//		System.out.println("The customer works full time.");
	//	}

	@Given("^the customer works ([a-zA-Z]{1,}) time$")
	public void the_customer_works_part_time(String workType) {
		System.out.println("The customer works "+workType+" time.");
	}

	//	@Given("working in govt office")
	//	public void working_in_Govt_office(){
	//		System.out.println("The customer works in a govt office");
	//	}

	@Given("^working in ([a-zA-Z]{1,}) office$")
	public void working_in_private_office(String officeType) {
		System.out.println("The customer works in a "+officeType+" office.");
	}

}
