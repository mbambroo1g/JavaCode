package com.fannie.step;

import cucumber.api.java.After;
import cucumber.api.java.Before;

//Global hook-- A @Before from cucumber is considred a hook.

public class GenericStep {

	@Before
	public void userHasToRegister() {
		System.out.println("###User has to register...###");
	}

	@After
	public void userLogsOut(){
		System.out.println("###Signing out###");
	}
}
