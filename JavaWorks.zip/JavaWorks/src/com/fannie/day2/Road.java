package com.fannie.day2;

public class Road {
	public static void randomRoadMethod() {
		
	}
	public static void main(String[] args) {
		System.out.println("Hello");
	}
}
