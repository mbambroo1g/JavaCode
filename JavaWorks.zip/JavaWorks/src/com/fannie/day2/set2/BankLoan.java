package com.fannie.day2.set2;

public abstract class BankLoan {
	public abstract void loanAmount();
	public abstract void repay(int repayAmount);
	public abstract void foreClosure();
}
