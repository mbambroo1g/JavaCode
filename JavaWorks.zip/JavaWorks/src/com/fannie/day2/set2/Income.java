package com.fannie.day2.set2;

public interface Income {
//100% abstract
	String companyName = "FannieMae";//SF - static, final
	public void checkCreditScore(int creditScore);
	public void verifyIncome(int income);
}
