package com.fannie.statics;

public class Addition {
	public static void add(int a, int b) {
		System.out.println(a+b);
	}
	public static void main(String[] args) {
//		Addition a = new Addition();
//		a.add(10, 20);
		add(20,30);
	}
}
