package com.fannie.collections;

public class ThreadExample {
	public static void main(String s[]) {
		System.out.println("Hello");
		System.out.println();
	}
}
