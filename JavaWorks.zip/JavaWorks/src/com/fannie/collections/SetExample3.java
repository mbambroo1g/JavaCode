package com.fannie.collections;

import java.util.TreeSet;

public class SetExample3 {
	public static void main(String[] args) {
		TreeSet<String> tree = new TreeSet<String>();
		
		tree.add("Pratik");
		tree.add("Sunil");
		tree.add("Medha");
		tree.add("Gregory");
		
		System.out.println(tree);
	}
}
