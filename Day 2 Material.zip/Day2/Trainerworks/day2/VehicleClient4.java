package com.fannie.day2;

public class VehicleClient4 {
	public static void main(String[] args) {
		Vehicle v = new Bike();
		
		v.accelerate();
		v.accelerate();
		v.accelerate();
		v.brake();
		v.brake();
	}
}
