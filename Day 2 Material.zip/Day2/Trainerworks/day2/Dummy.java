package com.fannie.day2;

public  abstract class Dummy {
	public static void main(String[] args) {
		System.out.println("hello");
	}
}
