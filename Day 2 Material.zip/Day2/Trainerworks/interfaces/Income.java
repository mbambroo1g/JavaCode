package com.fannie.interfaces;

public interface Income {
// 100% abstract 
	String companyName ="FannieMae";
	
	public void checkCreditScore();
	public void verifyIncome();
}
